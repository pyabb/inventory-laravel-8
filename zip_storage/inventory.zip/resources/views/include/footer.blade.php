    <!-- Jquery Core Js -->
    <script src="{{ url('plugins/jquery/jquery.min.js') }}"></script>
    <!-- Bootstrap Core Js -->
    <script src="{{ url('plugins/bootstrap/js/bootstrap.js') }}"></script>

    
     <script src="{{ url('plugins/momentjs/moment.js') }}"></script>


    <!-- Select Plugin Js -->
   <!-- <script src="{{ url('plugins/bootstrap-select/js/bootstrap-select.js') }}"></script>  -->

    <!-- Slimscroll Plugin Js -->
    <script src="{{ url('plugins/jquery-slimscroll/jquery.slimscroll.js') }}"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="{{ url('plugins/node-waves/waves.js') }}"></script>

    <!-- Jquery CountTo Plugin Js -->
    <script src="{{ url('plugins/jquery-countto/jquery.countTo.js') }}"></script>

    <!-- Morris Plugin Js -->
    <script src="{{ url('plugins/raphael/raphael.min.js') }}"></script>
    <script src="{{ url('plugins/morrisjs/morris.js') }}"></script>

    <!-- ChartJs -->
    <script src="{{ url('plugins/chartjs/Chart.bundle.js') }}"></script>

    <!-- Flot Charts Plugin Js -->
    <script src="{{ url('plugins/flot-charts/jquery.flot.js') }}"></script>
    <script src="{{ url('plugins/flot-charts/jquery.flot.resize.js') }}"></script>
    <script src="{{ url('plugins/flot-charts/jquery.flot.pie.js') }}"></script>
    <script src="{{ url('plugins/flot-charts/jquery.flot.categories.js') }}"></script>
    <script src="{{ url('plugins/flot-charts/jquery.flot.time.js') }}"></script>

    <!-- Sparkline Chart Plugin Js -->
    <script src="{{ url('plugins/jquery-sparkline/jquery.sparkline.js') }}"></script>

    <!-- Custom Js -->
    <script src="{{ url('js/admin.js') }}"></script>
    <script src="{{ url('js/pages/index.js') }}"></script>

    <!-- Demo Js -->
    <script src="{{ url('js/demo.js') }}"></script>
<!--      <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script> -->

         <!-- Bootstrap Material Datetime Picker Plugin Js -->
    <script src="{{ url('plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js') }}"></script>

    <!-- Bootstrap Datepicker Plugin Js -->
    <script src="{{ url('plugins/bootstrap-datepicker/js/bootstrap-datepicker.js') }}"></script>

    <script src="{{ url('js/pages/forms/basic-form-elements.js') }}"></script>
        <script src="{{ url('js/admin.js') }}"></script>
    <script src="{{ url('js/select2.min.js') }}"></script>


