<!DOCTYPE html>
<html>
<head>
	<title>Inventory | Login</title>
</head>
<body>

</body>
</html>