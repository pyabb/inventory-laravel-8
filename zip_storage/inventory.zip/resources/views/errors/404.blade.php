<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1 style="text-align:center">Opps Something Went Wrong <br>
         Or You Don't Have Permission to Access This Page 
    <a href="{{ url('/') }}">Go To Home page</a>
    </h1>
</body>
</html>